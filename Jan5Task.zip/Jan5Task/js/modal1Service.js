
(function() {
  "use strict";

	angular.module('myApp').service('modal1Service',function($http,$q){		
   
  	}); 



})();
