(function() {
    "use strict";

    // angular module
    angular.module('myApp', ['ui.router']);

})();